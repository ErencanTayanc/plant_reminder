# Platform Setup for Notifications

## Android

### 1. `android/app/src/main/AndroidManifest.xml`
Add inside `<manifest>`:
```xml
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>
<uses-permission android:name="android.permission.USE_EXACT_ALARM"/>
<uses-permission android:name="android.permission.CAMERA"/>
```

Add inside `<application>`:
```xml
<receiver android:exported="false"
    android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver"/>
<receiver android:exported="false"
    android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
    <intent-filter>
        <action android:name="android.intent.action.BOOT_COMPLETED"/>
        <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
        <action android:name="android.intent.action.QUICKBOOT_POWERON"/>
    </intent-filter>
</receiver>
```

### 2. `android/app/build.gradle`
Ensure `minSdkVersion` is at least 21:
```gradle
defaultConfig {
    minSdkVersion 21
}
```

---

## iOS

### `ios/Runner/Info.plist`
Add:
```xml
<key>NSCameraUsageDescription</key>
<string>To take a photo of your plant</string>
<key>NSPhotoLibraryUsageDescription</key>
<string>To pick a photo of your plant</string>
```

Notifications on iOS are requested at runtime via `DarwinInitializationSettings` — no extra plist entries needed.

---

## pubspec.yaml — add timezone assets
```yaml
flutter:
  assets:
    - packages/timezone/data/
```

---

## Run
```bash
flutter pub get
flutter run
```
